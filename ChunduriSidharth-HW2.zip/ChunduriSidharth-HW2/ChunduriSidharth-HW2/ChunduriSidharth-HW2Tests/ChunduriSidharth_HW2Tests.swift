//
//  ChunduriSidharth_HW2Tests.swift
//  ChunduriSidharth-HW2Tests
//
//  Created by Sidharth Chunduri on 9/17/25.
//

import Testing
@testable import ChunduriSidharth_HW2

struct ChunduriSidharth_HW2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
