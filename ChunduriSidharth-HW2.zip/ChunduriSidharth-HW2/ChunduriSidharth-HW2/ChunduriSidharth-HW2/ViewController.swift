// Project: ChunduriSidhart-HW2
// EID: sc69966
// Course: CS329E
//
//  ViewController.swift
//  ChunduriSidharth-HW2
//
//  Created by Sidharth Chunduri on 9/17/25.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var userIDField: UITextField!
    @IBOutlet weak var statusLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        statusLabel.text = "Not currently logged in"
        
        // Dismiss keyboard on background tap (required)
        // (Handled via touchesBegan below to avoid selector wiring issues)

        userIDField.delegate = self
        passwordField.delegate = self
    }
    
    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //check if we are editing the userID field
        if textField == userIDField {
            passwordField.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        return true
    }
    
    @IBAction func buttonPressed(_ sender: Any) {
        //create variabled from the text inputs
        let user = userIDField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let pass = passwordField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        
        //determine if login is invalid
        guard !user.isEmpty, !pass.isEmpty else {
            statusLabel.text = "Invalid login"      // required message
            return
        }
        statusLabel.text = "\(user) logged in"     // required message
    }

    // Handle background taps without a gesture recognizer
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
        super.touchesBegan(touches, with: event)
    }
}
